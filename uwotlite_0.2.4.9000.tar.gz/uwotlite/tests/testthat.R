library(testthat)
library(uwotlite)

test_check("uwotlite")
